/**
 * 
 */
/**
 * 
 */
module Plantie {
	requires java.desktop;
	requires java.sql;
}